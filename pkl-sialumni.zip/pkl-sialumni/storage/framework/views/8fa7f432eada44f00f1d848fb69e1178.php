<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="assets/login/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/login/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="assets/login/css/util.css">
	<link rel="stylesheet" type="text/css" href="assets/login/css/main.css">
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-form-title" style="background-image: url(assets/img/bgelitery.png);">
					<span class="login100-form-title-1">
						Sign Up
					</span>
				</div>

				<form method="POST" action="<?php echo e(route('register')); ?>" class="login100-form validate-form">
                    <?php echo csrf_field(); ?>

                    <?php echo csrf_field(); ?>


                    <div class="container-login100-form-btn">
                        

                        <a href="/auth/google" class="google-login-link">
                            <i class='bx bx-google nav_icon'></i> 
                            <span class="text-xs font-bold">Sign Up with Google</span>
                        </a>
                    </div>
                    
                    <div class="mt-4">
                        <label class="label-signup" for="ckb1">
                            Already have an account?
                        </label>
                        <a href="<?php echo e(route('login')); ?>" class="txt1">
                            Sign In
                        </a>
                    </div>
                    
                    
                    
				</form>
			</div>
		</div>
	</div>

	<script src="assets/login/vendor/jquery/jquery-3.2.1.min.js"></script>
	<script src="assets/login/js/main.js"></script>

</body>
</html>

<?php /**PATH /Users/thifaziada/Documents/PKL/pkl-sialumni/pkl-sialumni/resources/views/auth/register.blade.php ENDPATH**/ ?>