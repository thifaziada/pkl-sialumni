
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('All Alumnus')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

<div class="flex-1 min-h-screen p-4">
    <!-- Content -->
    <div class="container mx-auto">
        

        <form>
            <div class="flex space-x-3 my-5" >

                
                <select id="category" class="bg-gray-50 border border-gray-300 pl-5 text-green-600 text-sm rounded-full w-1/6 focus:ring-green-500 focus:border-green-500 block  p-2.5">
                    <option selected>Categories</option>
                    <option value="name">Name</option>
                    <option value="job">Job</option>
                    <option value="location">Location</option>
                </select>

                <div class="relative w-5/6">
                    <input type="search" name="search" placeholder="Search Name, Job, Location..." class="bg-white w-full h-10 px-4 rounded-full text-sm focus:outline-none">
                    <button type="submit" class="absolute right-5 top-2.5">
                      <svg class="h-4 w-4 fill-current" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" viewBox="0 0 56.966 56.966" style="enable-background:new 0 0 56.966 56.966;" xml:space="preserve" width="512px" height="512px">
                        <path d="M55.146,51.887L41.588,37.786c3.486-4.144,5.396-9.358,5.396-14.786c0-12.682-10.318-23-23-23s-23,10.318-23,23  s10.318,23,23,23c4.761,0,9.298-1.436,13.177-4.162l13.661,14.208c0.571,0.593,1.339,0.92,2.162,0.92  c0.779,0,1.518-0.297,2.079-0.837C56.255,54.982,56.293,53.08,55.146,51.887z M23.984,6c9.374,0,17,7.626,17,17s-7.626,17-17,17  s-17-7.626-17-17S14.61,6,23.984,6z"/>
                      </svg>
                    </button>
                </div>
            </div>
        </form>

        <div class="grid grid-cols-4 gap-3">
            

            <?php foreach ($alumniData as $alumni): ?>
                <div class="w-full max-w-sm bg-white border border-gray-200  rounded-lg shadow">
                    
                    <div class="flex flex-col items-center py-10">
                        <img class="w-24 h-24 mb-3 rounded-full shadow-lg" src="/assets/profile_pic/profile.png" alt="Bonnie image"/>
                        <h5 class="mb-1 text-xl font-medium text-gray-900 dark:text-white"><?php echo e($alumni->first_name); ?> <?php echo e($alumni->last_name); ?></h5>
                        <span class="text-sm text-gray-500 dark:text-gray-400"><?php echo e($alumni->city); ?>, <?php echo e($alumni->country); ?></span>
                        <div class="flex mt-4 md:mt-6">
                            <a href="<?php echo e(route('alumni.view',['id' => $alumni->id])); ?>" class="inline-flex items-center px-4 py-2 text-sm font-medium text-center text-white bg-green-600 rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300">View Profile</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>



<?php /**PATH /Users/thifaziada/Documents/PKL/pkl-sialumni/pkl-sialumni/resources/views/alumni.blade.php ENDPATH**/ ?>