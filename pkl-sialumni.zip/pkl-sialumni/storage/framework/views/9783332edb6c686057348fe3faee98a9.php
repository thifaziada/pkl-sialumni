<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Edit Profile</h2>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('alumni.update', $alumni->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="first_name">First Name:</label>
                <input type="text" name="first_name" value="<?php echo e($alumni->first_name); ?>" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="last_name">Last Name:</label>
                <input type="text" name="last_name" value="<?php echo e($alumni->last_name); ?>" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="birthday">Birthday:</label>
                <input type="date" name="birthday" value="<?php echo e($alumni->birthday); ?>" class="form-control" required>
            </div>

            <!-- Include other form fields for alumni profile here -->

            <div class="form-group">
                <label for="photo">Profile Photo:</label>
                <?php if($alumni->photo): ?>
                    <img src="<?php echo e(asset('storage/' . $alumni->photo)); ?>" alt="Profile Photo" class="img-thumbnail mb-2" style="max-width: 200px;">
                <?php endif; ?>
                <input type="file" name="photo" class="form-control-file">
            </div>

            <input type="submit" value="Update Profile" class="btn btn-primary">
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/thifaziada/Documents/PKL/pkl-sialumni/pkl-sialumni/resources/views/alumni/edit.blade.php ENDPATH**/ ?>